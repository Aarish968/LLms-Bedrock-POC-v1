#!/usr/bin/env python3
"""
Test script to verify large data insertion functionality.
"""

import os
import sys
from pathlib import Path

# Add the project root to Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from api.v1.services.repository_analysis_service import RepositoryAnalysisService
from api.core.logging import get_logger
from uuid import uuid4

logger = get_logger(__name__)

def test_large_data_insertion():
    """Test the database operations with large data similar to your error."""
    
    print("🧪 Testing large data insertion...")
    
    try:
        # Initialize the service
        service = RepositoryAnalysisService()
        
        # Test 1: Check and create table with new schema
        print("\n1️⃣ Testing table creation with large VARCHAR sizes...")
        table_success = service._check_and_create_table()
        
        if table_success:
            print("✅ Table check/creation successful with large VARCHAR sizes")
        else:
            print("❌ Table check/creation failed")
            return False
        
        # Test 2: Test with large data similar to your error
        print("\n2️⃣ Testing insertion with large TABLE_COLUMN_DETAILS...")
        
        # Create sample data with very large TABLE_COLUMN_DETAILS (similar to your error)
        large_table_details = """DC_SDP_SUB_TASK_TO_ENAB_SOLD_AS:[SOLD_AS_SERVICE_TYPE_ID,SUB_TASK_ID];DC_SDP_TYP_TASK:[ANCHOR_DATE_ID,CYCLE_ITERATOR_ID,DUE_DATE_OFFSET,FREQUENCY,HOURS,TASK_DESC,TASK_DESC_LONG,TASK_DOC_LINK,TASK_ID];DC_SDP_B_TASK_SUB_TASK:[SUB_TASK_ID,TASK_ID];DC_BUYING_PROGRAMS:[BUYING_PROGRAM_NAME,BUYING_PROGRAM_TYPE_ID];DC_PRICING_MODEL:[PRICING_MODEL_NAME,PRICING_TYPE_ID];DC_SDP_TYP_SUBTASK:[CYCLE_DAYS,FREQUENCY,HOURS,SUBTASK_DESC,SUBTASK_DESC_LONG,SUBTASK_DOC_LINK,SUB_TASK_ID];DC_SOLD_AS_SERVICE_TYPES:[SERVICE_TYPE_ID,SOLD_AS_SERVICE_NAME];DC_SDP_SUB_TASK_TO_ENAB_BUYING:[BUYING_PROGRAM_TYPE_ID,SUB_TASK_ID];DC_SDP_SUB_TASK_TO_ENAB_PRICING:[PRICING_TYPE_ID,SUB_TASK_ID]"""
        
        sample_large_data = [
            {
                'frontend_file': 'sdp.ts',
                'frontend_function': 'updateTask',
                'http_method': 'PATCH',
                'frontend_url': '/api/v2/admin/sdp/tasks/{id}',
                'backend_file': 'admin\\sdp\\subtasks.py',
                'backend_function': 'edit_sdp_subtask',
                'backend_route': '/api/v2/admin/sdp/tasks/{sub_task_id}',
                'database_tables': 'DC_SDP_SUB_TASK_TO_ENAB_SOLD_AS;DC_SDP_TYP_TASK;DC_SDP_B_TASK_SUB_TASK;DC_BUYING_PROGRAMS;DC_PRICING_MODEL;DC_SDP_TYP_SUBTASK;DC_SOLD_AS_SERVICE_TYPES;DC_SDP_SUB_TASK_TO_ENAB_BUYING;DC_SDP_SUB_TASK_TO_ENAB_PRICING',
                'stored_procedures': '',
                'flow_calls': '',
                'response_model': 'SDPSubTaskModel',
                'response_fields': '',
                'nested_fields': '',
                'table_column_details': large_table_details
            },
            {
                'frontend_file': 'sdp.ts',
                'frontend_function': 'createTask',
                'http_method': 'POST',
                'frontend_url': '/api/v2/admin/sdp/tasks',
                'backend_file': 'admin\\sdp\\subtasks.py',
                'backend_function': 'create_sdp_subtask',
                'backend_route': '/api/v2/admin/sdp/tasks',
                'database_tables': 'DC_SDP_SUB_TASK_TO_ENAB_SOLD_AS;DC_SDP_TYP_TASK;DC_SDP_B_TASK_SUB_TASK;DC_SDP_TYP_SUBTASK;DC_SDP_SUB_TASK_TO_ENAB_BUYING;DC_SDP_SUB_TASK_TO_ENAB_PRICING',
                'stored_procedures': '',
                'flow_calls': '',
                'response_model': 'SDPSubTaskModel',
                'response_fields': '',
                'nested_fields': '',
                'table_column_details': large_table_details
            }
        ]
        
        batch_result = service._batch_insert_data(sample_large_data)
        if batch_result > 0:
            print("✅ Large data insertion test successful")
            print(f"   Inserted {batch_result} rows with large TABLE_COLUMN_DETAILS")
        else:
            print("❌ Large data insertion test failed")
            return False
        
        print("\n🎉 All large data tests passed!")
        return True
        
    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        logger.error("Large data insertion test failed", error=str(e))
        return False

def main():
    """Main test function."""
    print("=" * 60)
    print("LARGE DATA INSERTION TEST")
    print("=" * 60)
    
    # Check if we're in mock mode
    service = RepositoryAnalysisService()
    if service.db_manager.mock_mode:
        print("⚠️ Running in mock mode - no actual database connection")
        print("   Configure Snowflake credentials in .env to test with real database")
        return
    
    success = test_large_data_insertion()
    
    if success:
        print("\n✅ All tests passed!")
    else:
        print("\n❌ Some tests failed!")
        sys.exit(1)

if __name__ == "__main__":
    main()