#!/usr/bin/env python3
"""
Test script to verify backslash escaping fix.
"""

def test_escape_function():
    """Test the escape function with problematic values."""
    
    def escape_value(value):
        if value is None or value == '':
            return "NULL"
        # Convert to string and escape single quotes and backslashes
        escaped = str(value).replace("'", "''").replace("\\", "\\\\")
        return f"'{escaped}'"
    
    print("🧪 Testing backslash escaping...")
    print("=" * 50)
    
    # Test cases from the failing rows
    test_cases = [
        "admin\\financial\\unverified.py",
        "manager\\users.py", 
        "support\\user.py",
        "workflows\\workflow_tagging.py",
        "normal_file.py",
        "file'with'quotes.py",
        "file\\with\\backslashes\\and'quotes.py"
    ]
    
    for test_case in test_cases:
        escaped = escape_value(test_case)
        print(f"Original: {test_case}")
        print(f"Escaped:  {escaped}")
        print()
    
    print("✅ All test cases processed successfully!")
    print("The backslashes are now properly escaped as \\\\\\\\ in SQL strings")

if __name__ == "__main__":
    test_escape_function()