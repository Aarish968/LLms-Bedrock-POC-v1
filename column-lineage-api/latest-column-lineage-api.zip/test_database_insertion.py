#!/usr/bin/env python3
"""
Test script to verify database insertion functionality.
"""

import os
import sys
from pathlib import Path

# Add the project root to Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from api.v1.services.repository_analysis_service import RepositoryAnalysisService
from api.core.logging import get_logger
from uuid import uuid4

logger = get_logger(__name__)

def test_database_operations():
    """Test the database operations for ACTION_TO_ENDPOINTS_TABLES_MAPPING table."""
    
    print("🧪 Testing database operations...")
    
    try:
        # Initialize the service
        service = RepositoryAnalysisService()
        
        # Test 1: Check and create table
        print("\n1️⃣ Testing table creation/check...")
        table_success = service._check_and_create_table()
        
        if table_success:
            print("✅ Table check/creation successful")
        else:
            print("❌ Table check/creation failed")
            return False
        
        # Test 2: Test CSV data insertion (if a CSV file exists)
        print("\n2️⃣ Looking for existing CSV files to test insertion...")
        
        # Look for CSV files in analysis results directory
        csv_files = list(service.analysis_results_dir.glob("*.csv"))
        
        if csv_files:
            test_csv = csv_files[0]
            print(f"📄 Found CSV file: {test_csv}")
            
            # Test insertion
            job_id = uuid4()
            insertion_success = service._insert_csv_data_to_database(str(test_csv), job_id)
            
            if insertion_success:
                print("✅ CSV data insertion successful")
            else:
                print("❌ CSV data insertion failed")
                return False
        else:
            print("ℹ️ No CSV files found for testing insertion")
            print("   You can test insertion after running an analysis")
        
        # Test 3: Test batch insert with sample data
        print("\n3️⃣ Testing batch insert with sample data...")
        sample_data = [
            {
                'frontend_file': 'test.ts',
                'frontend_function': 'testFunction',
                'http_method': 'GET',
                'frontend_url': '/api/test',
                'backend_file': 'test.py',
                'backend_function': 'test_handler',
                'backend_route': '/api/test',
                'database_tables': 'TEST_TABLE',
                'stored_procedures': '',
                'flow_calls': '',
                'response_model': 'TestResponse',
                'response_fields': 'id,name',
                'nested_fields': '',
                'table_column_details': 'TEST_TABLE:[ID,NAME]'
            }
        ]
        
        batch_result = service._batch_insert_data(sample_data)
        if batch_result > 0:
            print("✅ Batch insert test successful")
            print(f"   Inserted {batch_result} rows with timestamps")
        else:
            print("❌ Batch insert test failed")
            return False
        
        print("\n🎉 All database operations tests passed!")
        return True
        
    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        logger.error("Database operations test failed", error=str(e))
        return False

def main():
    """Main test function."""
    print("=" * 60)
    print("DATABASE INSERTION TEST - FIXED VERSION")
    print("=" * 60)
    
    # Check if we're in mock mode
    service = RepositoryAnalysisService()
    if service.db_manager.mock_mode:
        print("⚠️ Running in mock mode - no actual database connection")
        print("   Configure Snowflake credentials in .env to test with real database")
        return
    
    success = test_database_operations()
    
    if success:
        print("\n✅ All tests passed!")
    else:
        print("\n❌ Some tests failed!")
        sys.exit(1)

if __name__ == "__main__":
    main()