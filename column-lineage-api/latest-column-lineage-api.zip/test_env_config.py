#!/usr/bin/env python3
"""
Test script to verify environment variable configuration works
"""

import os
import sys
from pathlib import Path

def test_env_config():
    """Test the environment variable configuration"""
    
    print("Testing Environment Variable Configuration")
    print("=" * 45)
    
    # Test current environment variables
    print("🔍 Current Environment Variables:")
    
    # AWS CodeCommit variables
    aws_vars = {
        "AWS_CODECOMMIT_USERNAME": os.getenv("AWS_CODECOMMIT_USERNAME"),
        "AWS_CODECOMMIT_PASSWORD": os.getenv("AWS_CODECOMMIT_PASSWORD", "***hidden***" if os.getenv("AWS_CODECOMMIT_PASSWORD") else None),
        "AWS_CODECOMMIT_REGION": os.getenv("AWS_CODECOMMIT_REGION")
    }
    
    # Default repository variables
    repo_vars = {
        "DEFAULT_FRONTEND_REPO": os.getenv("DEFAULT_FRONTEND_REPO", "guided-workflow"),
        "DEFAULT_BACKEND_REPO": os.getenv("DEFAULT_BACKEND_REPO", "guided-workflow-backend")
    }
    
    print("\n📡 AWS CodeCommit Configuration:")
    for key, value in aws_vars.items():
        status = "✅ SET" if value else "❌ NOT SET"
        print(f"  {key:<25} {status}")
        if value and key != "AWS_CODECOMMIT_PASSWORD":
            print(f"    Value: {value}")
    
    print("\n🏗️  Default Repository Configuration:")
    for key, value in repo_vars.items():
        print(f"  {key:<25} ✅ {value}")
    
    # Test service initialization simulation
    print("\n🧪 Service Initialization Test:")
    try:
        # Simulate what the service does
        default_frontend = os.getenv("DEFAULT_FRONTEND_REPO", "guided-workflow")
        default_backend = os.getenv("DEFAULT_BACKEND_REPO", "guided-workflow-backend")
        
        print(f"  Frontend repo would be: {default_frontend}")
        print(f"  Backend repo would be:  {default_backend}")
        print("  ✅ Service initialization would work")
        
    except Exception as e:
        print(f"  ❌ Service initialization would fail: {e}")
    
    # Test API payload
    print("\n📤 Ultra Simple API Payload:")
    payload = '{"async_processing": true}'
    print(f"  {payload}")
    print("  ✅ Only 1 field required!")
    
    # Show .env.example content
    print("\n📄 .env.example Configuration:")
    env_example_path = Path(".env.example")
    if env_example_path.exists():
        try:
            with open(env_example_path, 'r') as f:
                lines = f.readlines()
            
            # Find and show relevant lines
            relevant_lines = []
            for line in lines:
                if any(keyword in line for keyword in ["DEFAULT_FRONTEND_REPO", "DEFAULT_BACKEND_REPO", "AWS_CODECOMMIT"]):
                    relevant_lines.append(line.strip())
            
            if relevant_lines:
                print("  Relevant configuration:")
                for line in relevant_lines:
                    print(f"    {line}")
            else:
                print("  ❌ Default repo variables not found in .env.example")
                
        except Exception as e:
            print(f"  ❌ Error reading .env.example: {e}")
    else:
        print("  ❌ .env.example file not found")
    
    print("\n🎯 Benefits of Environment Variable Approach:")
    print("  ✅ Ultra minimal API payload")
    print("  ✅ Easy to configure different environments")
    print("  ✅ No hardcoded values in code")
    print("  ✅ Secure credential management")
    print("  ✅ Perfect for containerized deployments")
    
    print("\n🚀 Ready to test with:")
    print('  curl -X POST "/analyze" -d \'{"async_processing": true}\'')

if __name__ == "__main__":
    test_env_config()