#!/usr/bin/env python3
"""
Test script for repository analysis integration.
This script tests the integration between repository cloning and action_to_table analysis.
"""

import asyncio
import os
import sys
from pathlib import Path
from uuid import uuid4

# Add the project root to Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from api.v1.services.repository_analysis_service import RepositoryAnalysisService
from api.v1.models.repository_analysis import RepositoryAnalysisRequest, AnalysisStatus


async def test_repository_analysis():
    """Test the complete repository analysis workflow."""
    print("Testing Repository Analysis Integration")
    print("=" * 50)
    
    # Create service instance
    service = RepositoryAnalysisService()
    
    # Show the expected clone paths
    print(f"Frontend clone directory: {service.frontend_clone_dir}")
    print(f"Backend clone directory: {service.backend_clone_dir}")
    
    # Create test request
    request = RepositoryAnalysisRequest(
        frontend_repo_name="guided-workflow",
        backend_repo_name="guided-workflow-backend",
        output_filename="test_analysis.csv"
    )
    
    # Create test job
    job_id = uuid4()
    print(f"Created test job: {job_id}")
    
    try:
        # Test the analysis workflow
        print("\n1. Testing repository cloning and analysis...")
        print(f"   Expected frontend path: {service.frontend_clone_dir / request.frontend_repo_name}")
        print(f"   Expected backend path: {service.backend_clone_dir / request.backend_repo_name}")
        
        await service.run_analysis(job_id, request, "test_user")
        
        # Check job status
        job = service.get_job(job_id)
        if job:
            print(f"Job Status: {job.status}")
            print(f"Message: {job.message}")
            if job.output_file:
                print(f"Output File: {job.output_file}")
                
                # Check if output file exists
                if Path(job.output_file).exists():
                    print("✅ CSV file created successfully!")
                    
                    # Show first few lines of the CSV
                    with open(job.output_file, 'r') as f:
                        lines = f.readlines()[:5]  # First 5 lines
                        print("\nFirst few lines of CSV:")
                        for i, line in enumerate(lines):
                            print(f"  {i+1}: {line.strip()}")
                else:
                    print("❌ CSV file not found")
            
            if job.error_message:
                print(f"Error: {job.error_message}")
        else:
            print("❌ Job not found")
            
    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()


def test_action_to_table_import():
    """Test importing action_to_table modules."""
    print("\nTesting action_to_table module import...")
    
    try:
        # Add action_to_table path
        action_to_table_path = Path(__file__).parent / "api" / "core" / "repo_analysis"
        sys.path.insert(0, str(action_to_table_path))
        
        from action_to_table import (
            CompleteFrontendAnalyzer, 
            CompleteBackendAnalyzer, 
            APIMapper,
            generate_reports
        )
        
        print("✅ Successfully imported action_to_table modules")
        return True
        
    except ImportError as e:
        print(f"❌ Failed to import action_to_table modules: {e}")
        return False
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return False


def main():
    """Main test function."""
    print("Repository Analysis Integration Test")
    print("=" * 60)
    
    # Test 1: Import test
    if not test_action_to_table_import():
        print("❌ Import test failed, skipping integration test")
        return
    
    # Test 2: Check environment variables
    print("\nChecking environment variables...")
    required_vars = [
        "AWS_CODECOMMIT_USERNAME",
        "AWS_CODECOMMIT_PASSWORD", 
        "AWS_CODECOMMIT_REGION"
    ]
    
    missing_vars = []
    for var in required_vars:
        if not os.getenv(var):
            missing_vars.append(var)
    
    if missing_vars:
        print(f"❌ Missing environment variables: {', '.join(missing_vars)}")
        print("Please set these variables before running the test")
        return
    else:
        print("✅ All required environment variables are set")
    
    # Test 3: Integration test
    print("\nRunning integration test...")
    try:
        asyncio.run(test_repository_analysis())
    except KeyboardInterrupt:
        print("\n⚠️  Test interrupted by user")
    except Exception as e:
        print(f"❌ Integration test failed: {e}")


if __name__ == "__main__":
    main()