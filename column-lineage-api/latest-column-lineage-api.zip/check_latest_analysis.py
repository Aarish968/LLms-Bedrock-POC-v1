#!/usr/bin/env python3
"""
Check if the latest analysis CSV file was created successfully.
"""

from pathlib import Path
import os


def check_analysis_files():
    """Check for analysis output files."""
    print("Checking for Analysis Output Files")
    print("=" * 40)
    
    current_dir = Path.cwd()
    print(f"Current directory: {current_dir}")
    
    # Files to check for
    files_to_check = [
        "latest-file.csv",
        "latest-file", 
        "new.csv",
        "repo_analysis_*.csv"
    ]
    
    print(f"\nChecking for specific files:")
    for filename in files_to_check:
        if "*" in filename:
            # Use glob for wildcard patterns
            matches = list(current_dir.glob(filename))
            if matches:
                print(f"✅ Found {filename}: {[f.name for f in matches]}")
                for match in matches:
                    stat = match.stat()
                    print(f"   - {match.name}: {stat.st_size} bytes")
            else:
                print(f"❌ Not found: {filename}")
        else:
            file_path = current_dir / filename
            if file_path.exists():
                stat = file_path.stat()
                print(f"✅ Found: {filename} ({stat.st_size} bytes)")
                
                # Show first few lines if it's a CSV
                if filename.endswith('.csv'):
                    try:
                        with open(file_path, 'r') as f:
                            lines = f.readlines()[:3]
                            print(f"   First few lines:")
                            for i, line in enumerate(lines):
                                print(f"     {i+1}: {line.strip()}")
                    except Exception as e:
                        print(f"   Error reading file: {e}")
            else:
                print(f"❌ Not found: {filename}")
    
    # List all CSV files in current directory
    print(f"\nAll CSV files in current directory:")
    csv_files = list(current_dir.glob("*.csv"))
    if csv_files:
        for csv_file in sorted(csv_files, key=lambda x: x.stat().st_mtime, reverse=True):
            stat = csv_file.stat()
            import datetime
            mod_time = datetime.datetime.fromtimestamp(stat.st_mtime)
            print(f"  - {csv_file.name} ({stat.st_size} bytes, {mod_time})")
    else:
        print("  No CSV files found")
    
    # Check if the script completed successfully by looking for the success message
    print(f"\nChecking for recent log files:")
    log_files = list(current_dir.glob("*.log"))
    for log_file in log_files:
        print(f"  Found log: {log_file.name}")


if __name__ == "__main__":
    check_analysis_files()