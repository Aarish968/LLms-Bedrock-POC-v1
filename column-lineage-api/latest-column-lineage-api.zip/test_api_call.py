#!/usr/bin/env python3
"""
Simple test script to call the repository analysis API
"""

import requests
import json
import time

def test_repo_analysis():
    """Test the repository analysis endpoint"""
    
    # API endpoint
    url = "http://localhost:8000/api/v1/repo-analysis/analyze"
    
    # Request payload - Ultra simple!
    payload = {
        "async_processing": True
    }
    
    print("Testing Repository Analysis API...")
    print(f"URL: {url}")
    print(f"Payload: {json.dumps(payload, indent=2)}")
    print("-" * 50)
    
    try:
        # Make the API call
        response = requests.post(url, json=payload)
        
        print(f"Status Code: {response.status_code}")
        print(f"Response Headers: {dict(response.headers)}")
        print(f"Response Body: {response.text}")
        
        if response.status_code == 200:
            result = response.json()
            job_id = result.get('job_id')
            
            if job_id:
                print(f"\n✅ Job started successfully!")
                print(f"Job ID: {job_id}")
                
                # Poll for job status
                status_url = f"http://localhost:8000/api/v1/repo-analysis/jobs/{job_id}"
                
                print(f"\nPolling job status...")
                for i in range(30):  # Poll for up to 5 minutes
                    time.sleep(10)
                    
                    try:
                        status_response = requests.get(status_url)
                        if status_response.status_code == 200:
                            status_data = status_response.json()
                            status = status_data.get('status')
                            message = status_data.get('message', '')
                            
                            print(f"Poll {i+1}: Status = {status}, Message = {message}")
                            
                            if status in ['COMPLETED', 'FAILED', 'CANCELLED']:
                                print(f"\n🏁 Job finished with status: {status}")
                                if status == 'COMPLETED':
                                    output_file = status_data.get('output_file')
                                    print(f"✅ Output file: {output_file}")
                                elif status == 'FAILED':
                                    error_msg = status_data.get('error_message', 'Unknown error')
                                    print(f"❌ Error: {error_msg}")
                                break
                        else:
                            print(f"Poll {i+1}: Failed to get status (HTTP {status_response.status_code})")
                    except Exception as e:
                        print(f"Poll {i+1}: Error getting status: {e}")
                else:
                    print("\n⏰ Polling timeout reached")
            else:
                print("❌ No job_id in response")
        else:
            print(f"❌ API call failed with status {response.status_code}")
            
    except requests.exceptions.ConnectionError:
        print("❌ Connection error - is the API server running?")
        print("Start the server with: python run.py")
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    test_repo_analysis()