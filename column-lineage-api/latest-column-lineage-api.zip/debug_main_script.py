#!/usr/bin/env python3
"""
Debug script to test main.py directly and see any errors.
"""

import subprocess
import sys
from pathlib import Path


def test_main_script():
    """Test the main.py script directly."""
    print("Testing main.py script directly")
    print("=" * 40)
    
    # Get paths
    main_script_path = Path(__file__).parent / "api" / "core" / "repo_analysis" / "main.py"
    frontend_path = Path("Cloned_repo/Frontend/guided-workflow")
    backend_path = Path("Cloned_repo/Backend/guided-workflow-backend")
    output_base = "debug_test"
    
    print(f"Script path: {main_script_path}")
    print(f"Script exists: {main_script_path.exists()}")
    print(f"Frontend path: {frontend_path}")
    print(f"Frontend exists: {frontend_path.exists()}")
    print(f"Backend path: {backend_path}")
    print(f"Backend exists: {backend_path.exists()}")
    print(f"Output base: {output_base}")
    print(f"Working directory: {Path.cwd()}")
    
    if not frontend_path.exists():
        print("❌ Frontend path doesn't exist - repositories need to be cloned first")
        return
    
    if not backend_path.exists():
        print("❌ Backend path doesn't exist - repositories need to be cloned first")
        return
    
    # Prepare command
    cmd_args = [
        sys.executable, str(main_script_path),
        "--frontend", str(frontend_path),
        "--backend", str(backend_path),
        "--output", output_base,
    ]
    
    print(f"\nExecuting command:")
    print(f"  {' '.join(cmd_args)}")
    print("\n" + "=" * 40)
    
    try:
        # Run the script
        result = subprocess.run(
            cmd_args,
            capture_output=True,
            text=True,
            cwd=Path.cwd(),
            timeout=300  # 5 minute timeout
        )
        
        print(f"Return code: {result.returncode}")
        
        if result.stdout:
            print(f"\nSTDOUT:")
            print(result.stdout)
        
        if result.stderr:
            print(f"\nSTDERR:")
            print(result.stderr)
        
        # Check if CSV was created
        expected_csv = f"{output_base}.csv"
        if Path(expected_csv).exists():
            print(f"\n✅ CSV file created: {expected_csv}")
            
            # Show file size
            file_size = Path(expected_csv).stat().st_size
            print(f"   File size: {file_size} bytes")
            
            # Show first few lines
            with open(expected_csv, 'r') as f:
                lines = f.readlines()[:3]
                print(f"   First few lines:")
                for i, line in enumerate(lines):
                    print(f"     {i+1}: {line.strip()}")
        else:
            print(f"\n❌ CSV file not created: {expected_csv}")
        
    except subprocess.TimeoutExpired:
        print("❌ Script timed out after 5 minutes")
    except Exception as e:
        print(f"❌ Error running script: {e}")


def check_python_path():
    """Check if the script can import required modules."""
    print("\nChecking Python imports...")
    
    try:
        # Add the repo_analysis path
        repo_analysis_path = Path(__file__).parent / "api" / "core" / "repo_analysis"
        sys.path.insert(0, str(repo_analysis_path))
        
        from action_to_table import CompleteFrontendAnalyzer, CompleteBackendAnalyzer, APIMapper
        print("✅ Successfully imported action_to_table modules")
        
        # Test creating analyzers
        frontend_path = "Cloned_repo/Frontend/guided-workflow"
        backend_path = "Cloned_repo/Backend/guided-workflow-backend"
        
        if Path(frontend_path).exists() and Path(backend_path).exists():
            print("✅ Repository paths exist, testing analyzers...")
            
            try:
                frontend_analyzer = CompleteFrontendAnalyzer(frontend_path)
                print("✅ Frontend analyzer created successfully")
                
                backend_analyzer = CompleteBackendAnalyzer(backend_path)
                print("✅ Backend analyzer created successfully")
                
            except Exception as e:
                print(f"❌ Error creating analyzers: {e}")
        else:
            print("⚠️  Repository paths don't exist, skipping analyzer test")
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
    except Exception as e:
        print(f"❌ Unexpected error: {e}")


def main():
    """Main debug function."""
    print("Main.py Script Debug Tool")
    print("=" * 50)
    
    # Check imports first
    check_python_path()
    
    # Test the script
    test_main_script()


if __name__ == "__main__":
    main()