#!/usr/bin/env python3
"""
Test script to run insertion with detailed logging to identify missing rows.
"""

import os
import sys
import logging
from pathlib import Path

# Add the project root to Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

# Set up detailed logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('insertion_debug.log')
    ]
)

from api.v1.services.repository_analysis_service import RepositoryAnalysisService
from uuid import uuid4

def test_insertion_with_detailed_logs():
    """Test insertion with detailed logging."""
    
    print("🔍 Testing insertion with detailed logging...")
    print("=" * 60)
    
    try:
        # Initialize the service
        service = RepositoryAnalysisService()
        
        if service.db_manager.mock_mode:
            print("⚠️ Running in mock mode - no actual database connection")
            return
        
        # Find the most recent CSV file
        repo_analyze_dir = Path("Repo_Analyze")
        if not repo_analyze_dir.exists():
            print("❌ Repo_Analyze directory not found")
            return
        
        csv_files = list(repo_analyze_dir.glob("*.csv"))
        if not csv_files:
            print("❌ No CSV files found in Repo_Analyze directory")
            return
        
        # Get the most recent CSV file
        latest_csv = max(csv_files, key=lambda x: x.stat().st_mtime)
        print(f"📄 Using CSV file: {latest_csv}")
        
        # Test the insertion
        job_id = uuid4()
        success = service._insert_csv_data_to_database(str(latest_csv), job_id)
        
        if success:
            print("✅ Insertion completed")
        else:
            print("❌ Insertion failed")
        
        print("\n📋 Check 'insertion_debug.log' for detailed logs")
        
    except Exception as e:
        print(f"❌ Test failed with error: {e}")

if __name__ == "__main__":
    test_insertion_with_detailed_logs()