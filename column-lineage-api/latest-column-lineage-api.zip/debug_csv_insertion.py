#!/usr/bin/env python3
"""
Debug script to identify which CSV rows are failing to insert.
"""

import csv
import sys
from pathlib import Path

# Add the project root to Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

def analyze_csv_file(csv_file_path):
    """Analyze the CSV file to identify potential issues."""
    
    print(f"🔍 Analyzing CSV file: {csv_file_path}")
    print("=" * 60)
    
    if not Path(csv_file_path).exists():
        print(f"❌ CSV file not found: {csv_file_path}")
        return
    
    try:
        with open(csv_file_path, 'r', encoding='utf-8') as csvfile:
            # Detect delimiter
            sample = csvfile.read(1024)
            csvfile.seek(0)
            sniffer = csv.Sniffer()
            delimiter = sniffer.sniff(sample).delimiter
            
            print(f"📊 Detected delimiter: '{delimiter}'")
            
            reader = csv.DictReader(csvfile, delimiter=delimiter)
            
            total_rows = 0
            problematic_rows = []
            
            for row_num, row in enumerate(reader, 1):
                total_rows += 1
                
                # Check for potential issues
                issues = []
                
                # Check for missing required fields
                required_fields = ['Frontend_File', 'Frontend_Function', 'HTTP_Method']
                for field in required_fields:
                    if not row.get(field) or row.get(field).strip() == '':
                        issues.append(f"Missing {field}")
                
                # Check for very long values that might cause issues
                for key, value in row.items():
                    if value and len(str(value)) > 10000:
                        issues.append(f"Very long {key} ({len(str(value))} chars)")
                
                # Check for special characters that might cause SQL issues
                for key, value in row.items():
                    if value and ("'" in str(value) and str(value).count("'") > 10):
                        issues.append(f"Many quotes in {key}")
                
                # Check for newlines in data
                for key, value in row.items():
                    if value and ('\n' in str(value) or '\r' in str(value)):
                        issues.append(f"Newlines in {key}")
                
                if issues:
                    problematic_rows.append({
                        'row_number': row_num,
                        'issues': issues,
                        'frontend_file': row.get('Frontend_File', 'N/A'),
                        'frontend_function': row.get('Frontend_Function', 'N/A'),
                        'data': row
                    })
            
            print(f"📈 Total rows in CSV: {total_rows}")
            print(f"⚠️ Potentially problematic rows: {len(problematic_rows)}")
            
            if problematic_rows:
                print("\n🚨 Problematic rows details:")
                for prob_row in problematic_rows:
                    print(f"  Row {prob_row['row_number']}: {prob_row['frontend_file']} - {prob_row['frontend_function']}")
                    print(f"    Issues: {', '.join(prob_row['issues'])}")
                    
                    # Show the actual data for the first few problematic rows
                    if prob_row['row_number'] <= 5:
                        print(f"    Data: {prob_row['data']}")
                    print()
            
            # Check for empty rows at the end
            csvfile.seek(0)
            lines = csvfile.readlines()
            empty_lines = 0
            for line in reversed(lines):
                if line.strip() == '' or line.strip() == ',,,,,,,,,,,,,':
                    empty_lines += 1
                else:
                    break
            
            if empty_lines > 0:
                print(f"📝 Empty lines at end of file: {empty_lines}")
            
            print(f"📄 Total lines in file: {len(lines)}")
            print(f"📊 Data rows (excluding header): {total_rows}")
            print(f"🔢 Expected insertions: {total_rows}")
            
    except Exception as e:
        print(f"❌ Error analyzing CSV: {e}")

def main():
    """Main function."""
    # Look for the most recent CSV file
    repo_analyze_dir = Path("Repo_Analyze")
    if not repo_analyze_dir.exists():
        print("❌ Repo_Analyze directory not found")
        return
    
    csv_files = list(repo_analyze_dir.glob("*.csv"))
    if not csv_files:
        print("❌ No CSV files found in Repo_Analyze directory")
        return
    
    # Get the most recent CSV file
    latest_csv = max(csv_files, key=lambda x: x.stat().st_mtime)
    
    analyze_csv_file(latest_csv)

if __name__ == "__main__":
    main()