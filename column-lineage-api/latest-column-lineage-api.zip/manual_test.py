#!/usr/bin/env python3
"""
Manual test to verify the new auto-generated filename and directory structure
"""

import os
from pathlib import Path
from datetime import datetime

def test_new_structure():
    """Test the new auto-generated filename and directory structure"""
    
    print("Testing new repository analysis structure...")
    print("=" * 50)
    
    # Test auto-generated filename format
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    expected_filename = f"repo_analysis_{timestamp}.csv"
    expected_path = Path("Repo_Analyze") / expected_filename
    
    print(f"Expected auto-generated filename: {expected_filename}")
    print(f"Expected full path: {expected_path}")
    print()
    
    # Check if Repo_Analyze directory exists
    repo_analyze_dir = Path("Repo_Analyze")
    print(f"Repo_Analyze directory exists: {'✅ YES' if repo_analyze_dir.exists() else '❌ NO'}")
    
    if repo_analyze_dir.exists():
        # List existing CSV files in the directory
        csv_files = list(repo_analyze_dir.glob("*.csv"))
        print(f"Existing CSV files in Repo_Analyze: {len(csv_files)}")
        
        for csv_file in csv_files:
            stat = csv_file.stat()
            print(f"  - {csv_file.name} ({stat.st_size} bytes)")
            
            # Check if it's a valid analysis file
            try:
                with open(csv_file, 'r', encoding='utf-8') as f:
                    first_line = f.readline().strip()
                    if 'Frontend_File' in first_line:
                        print(f"    ✅ Valid analysis CSV")
                    else:
                        print(f"    ⚠️  Unknown CSV format")
            except Exception as e:
                print(f"    ❌ Error reading file: {e}")
    
    print()
    print("New ULTRA SIMPLE API payload format:")
    print("""
    {
        "async_processing": true
    }
    """)
    
    print("Repository names now come from environment variables:")
    print("  DEFAULT_FRONTEND_REPO=guided-workflow")
    print("  DEFAULT_BACKEND_REPO=guided-workflow-backend")
    
    print()
    print("✅ Changes implemented:")
    print("  - Ultra minimal payload - only async_processing flag")
    print("  - Repository names from environment variables") 
    print("  - Auto-generate filenames with timestamp")
    print("  - Store CSV files in 'Repo_Analyze/' directory")
    print("  - Files named as: repo_analysis_YYYYMMDD_HHMMSS.csv")

if __name__ == "__main__":
    test_new_structure()